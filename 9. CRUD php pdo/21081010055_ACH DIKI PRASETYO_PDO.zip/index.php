<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Menu</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
	<div class="container">
	<h1>MENU</h1>
		<ul>
			<li><a href="input_customer.php">1. Input Data Customer</a></li>
			<li><a href="tampil_customer.php">2. Tampilkan Data Customer</a></li>
			<li><a href="input_product.php">3. Input Data Product</a></li>
			<li><a href="tampil_product.php">4. Tampilkan Data Product</a></li>
		</ul>
	</div>
</body>
</html>